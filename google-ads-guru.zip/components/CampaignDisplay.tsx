import React from 'react';
import type { Campaign, CampaignGoal } from '../types';
import { TargetIcon, KeyIcon, MinusCircleIcon, ShoppingCartIcon, MousePointerClickIcon, UserPlusIcon, MegaphoneIcon, PercentIcon, TrendingUpIcon, DollarSignCircleIcon, LightbulbIcon } from './icons';

const goalIcons: Record<CampaignGoal, React.ReactNode> = {
    'Sales': <ShoppingCartIcon className="w-5 h-5" />,
    'Website Traffic': <MousePointerClickIcon className="w-5 h-5" />,
    'Lead Generation': <UserPlusIcon className="w-5 h-5" />,
    'Brand Awareness': <MegaphoneIcon className="w-5 h-5" />,
};

const CampaignDisplay: React.FC<{ campaign: Campaign }> = ({ campaign }) => {
  return (
    <div className="mt-4 p-4 border border-blue-500/30 rounded-lg bg-gray-800/50">
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-lg font-bold text-blue-300">{campaign.campaignName}</h3>
        <div className="flex items-center gap-2 text-sm bg-blue-900/50 text-blue-200 px-3 py-1 rounded-full border border-blue-500/30">
            {goalIcons[campaign.goal]}
            <span>{campaign.goal}</span>
        </div>
      </div>

      {campaign.expectedKpis && (
        <div className="mb-4 p-3 bg-gray-900/50 rounded-md border border-gray-700">
          <h5 className="text-sm font-medium text-gray-300 mb-3 text-center">Expected Monthly KPIs</h5>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="flex items-center justify-center gap-2 mb-1 text-purple-300">
                <PercentIcon className="w-4 h-4" />
                <span className="text-xs font-semibold">CTR</span>
              </div>
              <p className="text-lg font-bold">{campaign.expectedKpis.ctr}</p>
            </div>
            <div>
              <div className="flex items-center justify-center gap-2 mb-1 text-teal-300">
                <TrendingUpIcon className="w-4 h-4" />
                <span className="text-xs font-semibold">Conversion Rate</span>
              </div>
              <p className="text-lg font-bold">{campaign.expectedKpis.conversionRate}</p>
            </div>
            <div>
              <div className="flex items-center justify-center gap-2 mb-1 text-orange-300">
                <DollarSignCircleIcon className="w-4 h-4" />
                <span className="text-xs font-semibold">CPA</span>
              </div>
              <p className="text-lg font-bold">{campaign.expectedKpis.cpa}</p>
            </div>
          </div>
        </div>
      )}

      {campaign.negativeKeywords && campaign.negativeKeywords.length > 0 && (
        <div className="mb-4 p-3 bg-gray-700/50 rounded-md">
            <h5 className="text-sm font-medium text-gray-300 mb-2 flex items-center gap-1.5">
                <MinusCircleIcon className="w-4 h-4 text-red-400" />
                Negative Keywords (to exclude)
            </h5>
            <div className="flex flex-wrap gap-2">
                {campaign.negativeKeywords.map((kw, i) => (
                    <span key={i} className="px-2 py-1 text-xs bg-red-900/50 text-red-300 border border-red-500/30 rounded-full">{kw}</span>
                ))}
            </div>
        </div>
      )}

      <div className="space-y-4">
        {campaign.adGroups.map((adGroup, index) => (
          <div key={index} className="p-3 bg-gray-700/50 rounded-md">
            <div className="flex items-center gap-2 mb-2">
                <TargetIcon className="w-5 h-5 text-green-400" />
                <h4 className="font-semibold text-green-300">{adGroup.name}</h4>
            </div>
            
            <div className="mb-3">
                <h5 className="text-sm font-medium text-gray-300 mb-1 flex items-center gap-1.5"><KeyIcon className="w-4 h-4" /> Core Keywords</h5>
                <div className="flex flex-wrap gap-2">
                    {adGroup.keywords.map((kw, i) => (
                        <span key={i} className="px-2 py-1 text-xs bg-gray-600 rounded-full">{kw}</span>
                    ))}
                </div>
            </div>

            {adGroup.suggestedKeywords && adGroup.suggestedKeywords.length > 0 && (
                <div className="mb-3">
                    <h5 className="text-sm font-medium text-gray-400 mb-1 flex items-center gap-1.5"><LightbulbIcon className="w-4 h-4 text-yellow-300" /> Suggested Keywords</h5>
                    <div className="flex flex-wrap gap-2">
                        {adGroup.suggestedKeywords.map((kw, i) => (
                            <span key={i} className="px-2 py-1 text-xs bg-yellow-900/50 text-yellow-300 border border-yellow-500/30 rounded-full">{kw}</span>
                        ))}
                    </div>
                </div>
            )}

            <h5 className="text-sm font-medium text-gray-300 mb-2">Ad Previews</h5>
            <div className="space-y-3">
                {adGroup.ads.map((ad, i) => (
                    <div key={i} className="p-3 border border-gray-600 rounded bg-gray-900">
                        <p className="text-blue-400 font-semibold">{ad.headline1} | {ad.headline2} {ad.headline3 && `| ${ad.headline3}`}</p>

                        <p className="text-sm text-gray-300">{ad.description1}</p>
                        <p className="text-sm text-gray-300">{ad.description2}</p>
                    </div>
                ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CampaignDisplay;