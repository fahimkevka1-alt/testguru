import React, { useState } from 'react';
import type { ChatMessage as ChatMessageType } from '../types';
import { GoogleIcon } from './icons';
import CampaignDisplay from './CampaignDisplay';
import PricingTiers from './PricingTiers';
import CampaignSetupGuide from './CampaignSetupGuide';

const SimpleMarkdown: React.FC<{ text: string }> = ({ text }) => {
    const lines = text.split('\n');
    return (
        <div>
            {lines.map((line, i) => {
                if (line.startsWith('* ')) {
                    return <li key={i} className="ml-5 list-disc">{line.substring(2)}</li>;
                }
                line = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
                return <p key={i} className="mb-2" dangerouslySetInnerHTML={{ __html: line }} />;
            })}
        </div>
    );
};


const ChatMessage: React.FC<{ message: ChatMessageType }> = ({ message }) => {
  const isModel = message.role === 'model';
  const [showGuide, setShowGuide] = useState(false);

  return (
    <div className={`flex items-start gap-3 my-4 ${isModel ? '' : 'flex-row-reverse'}`}>
      <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${isModel ? 'bg-blue-600' : 'bg-gray-700'}`}>
        {isModel ? <GoogleIcon className="w-6 h-6 text-white" /> : 'U'}
      </div>
      <div className={`p-4 rounded-lg max-w-3xl w-full ${isModel ? 'bg-gray-800 rounded-tl-none' : 'bg-blue-800 rounded-tr-none'}`}>
        <div className="text-white prose prose-invert prose-p:my-0">
          <SimpleMarkdown text={message.text} />
        </div>

        {message.campaign && <CampaignDisplay campaign={message.campaign} />}
        {message.pricingTiers && <PricingTiers tiers={message.pricingTiers} />}

        {message.campaign && !showGuide && (
            <div className="mt-4">
                <button
                    onClick={() => setShowGuide(true)}
                    className="w-full px-4 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition-colors"
                >
                    Show me how to set this up!
                </button>
            </div>
        )}
        {message.campaign && showGuide && <CampaignSetupGuide />}

      </div>
    </div>
  );
};

export default ChatMessage;