import React, { useState } from 'react';
import { CheckCircleIcon, RocketLaunchIcon } from './icons';

const setupSteps = [
    {
        title: "Go to Google Ads",
        description: "First, let's go to the playground! Open up the Google Ads website. It's like the big front gate to where we'll build everything. You can find it at ads.google.com."
    },
    {
        title: "Create a New Campaign",
        description: "Look for a big blue button with a plus (+) sign, usually labeled 'New campaign'. This is our 'Start Building' button. Click it to begin!"
    },
    {
        title: "Copy Campaign Name & Goal",
        description: "Remember the name we chose for our campaign? Copy that name and paste it into the 'Campaign Name' box. Then, choose the goal we picked, like 'Sales' or 'Website Traffic'."
    },
    {
        title: "Set Your Budget",
        description: "Now for the pocket money! Find the budget section and type in the daily budget. You can calculate this by dividing your monthly budget by 30.4. This tells Google how much we want to spend each day."
    },
    {
        title: "Create Ad Groups",
        description: "Time to make our teams! For each Ad Group we planned, create a new one inside your campaign. Just copy and paste the name I gave you for each one."
    },
    {
        title: "Add Your Magic Words (Keywords)",
        description: "Inside each Ad Group, there's a box for your 'magic words', or Keywords. Copy all the Core Keywords from my plan and paste them in here. This tells Google when to show your ad."
    },
    {
        title: "Add Negative Keywords",
        description: "Let's tell Google what we *don't* want. Find the Negative Keywords section in your campaign settings. Copy the list of words I gave you and paste them in. This saves us money!"
    },
    {
        title: "Write Your Ads",
        description: "This is the fun part! For each Ad Group, create a new ad. Copy and paste the headlines and descriptions from my plan into the boxes. Make your ad shine!"
    },
    {
        title: "Review and Launch!",
        description: "Look over everything one last time. Does it all look correct? If yes, hit the big blue 'Publish' or 'Launch' button. Your ads are now live on the internet! Hooray!"
    }
];


const CampaignSetupGuide: React.FC = () => {
    const [currentStep, setCurrentStep] = useState(0);

    const handleNextStep = () => {
        if (currentStep < setupSteps.length) {
            setCurrentStep(currentStep + 1);
        }
    };

    const handleRestart = () => {
        setCurrentStep(0);
    }

    const isCompleted = currentStep >= setupSteps.length;

    return (
        <div className="mt-4 p-4 border border-green-500/30 rounded-lg bg-gray-800/50">
            <h3 className="text-lg font-bold text-green-300 mb-3">Your Campaign Setup Checklist</h3>

            {isCompleted ? (
                 <div className="text-center p-6 bg-gray-900/50 rounded-lg">
                    <RocketLaunchIcon className="w-12 h-12 text-green-400 mx-auto mb-4" />
                    <h4 className="text-xl font-bold text-white mb-2">Campaign Launched!</h4>
                    <p className="text-gray-300 mb-4">Congratulations! You've completed all the steps to set up your Google Ads campaign.</p>
                    <button
                        onClick={handleRestart}
                        className="px-4 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition-colors"
                    >
                        Start Over
                    </button>
                </div>
            ) : (
                <>
                    <div className="flex items-center justify-between mb-4">
                        <span className="text-sm font-semibold text-gray-400">
                            Step {currentStep + 1} of {setupSteps.length}
                        </span>
                        <div className="w-2/3 bg-gray-700 rounded-full h-2.5">
                            <div className="bg-green-500 h-2.5 rounded-full" style={{ width: `${((currentStep + 1) / setupSteps.length) * 100}%` }}></div>
                        </div>
                    </div>

                    <div className="p-4 bg-gray-900/50 rounded-lg mb-4">
                        <h4 className="font-bold text-lg text-white mb-2">{setupSteps[currentStep].title}</h4>
                        <p className="text-gray-300">{setupSteps[currentStep].description}</p>
                    </div>

                    <button
                        onClick={handleNextStep}
                        className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition-colors"
                    >
                        <CheckCircleIcon className="w-5 h-5" />
                        I've done this! Next Step
                    </button>
                </>
            )}
        </div>
    );
};

export default CampaignSetupGuide;
