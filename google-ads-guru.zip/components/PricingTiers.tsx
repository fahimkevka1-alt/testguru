
import React from 'react';
import type { PricingTier } from '../types';
import { PriceTagIcon } from './icons';

const PricingTiers: React.FC<{ tiers: PricingTier[] }> = ({ tiers }) => {
  return (
    <div className="mt-4">
        <h3 className="text-lg font-bold text-yellow-300 mb-3 flex items-center gap-2">
            <PriceTagIcon className="w-5 h-5" />
            Pricing Options
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {tiers.map((tier, index) => (
            <div key={index} className="p-4 border border-yellow-500/30 rounded-lg bg-gray-800/50 text-center flex flex-col">
                <h4 className="font-bold text-lg text-yellow-300">{tier.tierName}</h4>
                <p className="text-2xl font-bold my-2">${tier.monthlyBudget}<span className="text-base font-normal text-gray-400">/mo</span></p>
                <p className="text-sm text-gray-300 flex-grow">{tier.description}</p>
            </div>
            ))}
      </div>
    </div>
  );
};

export default PricingTiers;
