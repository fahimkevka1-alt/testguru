import { GoogleGenAI, FunctionDeclaration, Type } from "@google/genai";
import type { Campaign, PricingTier, CampaignGoal } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const createGoogleAdsCampaign: FunctionDeclaration = {
  name: "createGoogleAdsCampaign",
  description: "Creates a structured Google Ads campaign with ad groups, keywords, ad copy, negative keywords, and expected KPIs, tailored to a specific campaign goal.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      campaignName: {
        type: Type.STRING,
        description: "The overall name for the campaign."
      },
      goal: {
        type: Type.STRING,
        description: "The primary goal of the campaign. Must be one of: 'Website Traffic', 'Sales', 'Lead Generation', 'Brand Awareness'.",
        enum: ['Website Traffic', 'Sales', 'Lead Generation', 'Brand Awareness']
      },
      negativeKeywords: {
        type: Type.ARRAY,
        description: "A list of negative keywords for the entire campaign to prevent ads from showing on irrelevant searches (e.g., 'free', 'jobs', 'repair').",
        items: { type: Type.STRING }
      },
      expectedKpis: {
        type: Type.OBJECT,
        description: "A set of estimated Key Performance Indicators (KPIs) for the campaign, tailored to the selected goal.",
        properties: {
          ctr: {
            type: Type.STRING,
            description: "The expected Click-Through Rate (CTR), e.g., '2% - 4%'."
          },
          conversionRate: {
            type: Type.STRING,
            description: "The expected Conversion Rate, e.g., '1.5% - 3%' or 'N/A for Brand Awareness'."
          },
          cpa: {
            type: Type.STRING,
            description: "The expected Cost Per Acquisition (CPA), e.g., '$30 - $50' or 'Not a primary metric'."
          }
        },
        required: ["ctr", "conversionRate", "cpa"]
      },
      adGroups: {
        type: Type.ARRAY,
        description: "A list of ad groups within the campaign.",
        items: {
          type: Type.OBJECT,
          properties: {
            name: {
              type: Type.STRING,
              description: "The name of the ad group, typically themed around a set of keywords."
            },
            keywords: {
              type: Type.ARRAY,
              description: "A list of core, highly relevant keywords that will trigger ads in this ad group. Should be tailored to the campaign goal.",
              items: { type: Type.STRING }
            },
            suggestedKeywords: {
              type: Type.ARRAY,
              description: "A list of additional suggested keywords (e.g., long-tail, related searches) for the ad group to expand reach. These are based on the business description and goal.",
              items: { type: Type.STRING }
            },
            ads: {
              type: Type.ARRAY,
              description: "A list of ad copy variations for this ad group. The copy should be written to drive the campaign goal.",
              items: {
                type: Type.OBJECT,
                properties: {
                  headline1: { type: Type.STRING, description: "The first headline of the ad." },
                  headline2: { type: Type.STRING, description: "The second headline of the ad." },
                  headline3: { type: Type.STRING, description: "The optional third headline of the ad." },
                  description1: { type: Type.STRING, description: "The first description line." },
                  description2: { type: Type.STRING, description: "The second description line." },
                },
                required: ["headline1", "headline2", "description1", "description2"]
              }
            }
          },
          required: ["name", "keywords", "ads"]
        }
      }
    },
    required: ["campaignName", "goal", "adGroups", "negativeKeywords", "expectedKpis"]
  }
};

const providePricingOptions: FunctionDeclaration = {
  name: "providePricingOptions",
  description: "Provides a few budget-friendly pricing options for the campaign.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      tiers: {
        type: Type.ARRAY,
        description: "A list of pricing tiers.",
        items: {
          type: Type.OBJECT,
          properties: {
            tierName: { type: Type.STRING, description: "The name of the tier, e.g., 'Starter', 'Growth'." },
            monthlyBudget: { type: Type.NUMBER, description: "The recommended monthly budget in USD." },
            description: { type: Type.STRING, description: "A brief description of what this budget can achieve." }
          },
          required: ["tierName", "monthlyBudget", "description"]
        }
      }
    },
    required: ["tiers"]
  }
};

const systemInstruction = `You are an expert Google Ads campaign manager.
Your goal is to help business owners create economical and effective ad campaigns.
The user will first select a campaign goal ('Website Traffic', 'Sales', 'Lead Generation', or 'Brand Awareness').
Then, have a conversation to gather all necessary information: the business name, what they sell, and their specific target audience. The user may also specify their desired monthly budget. Ask follow-up questions if needed to get clarity.
Once you have sufficient details, you MUST call the 'createGoogleAdsCampaign' function to structure a complete campaign proposal. This proposal MUST be tailored to the user's selected campaign goal. For each ad group, provide a list of core 'keywords' and also a list of 'suggestedKeywords' to offer more options. For example, a 'Sales' campaign should have transaction-focused keywords and ad copy, while a 'Brand Awareness' campaign might have broader keywords. The proposal MUST also include a list of relevant 'negativeKeywords' and a set of realistic 'expectedKpis' (CTR, Conversion Rate, CPA) that align with the campaign's goal.
After creating the campaign, you MUST call the 'providePricingOptions' function to suggest a few budget options. If the user specified a budget, tailor your suggestions to it.
Use your knowledge to inform your campaign and pricing suggestions.`;


export async function getAdCampaignAdvice(
  prompt: string,
  history: { role: "user" | "model"; parts: { text: string }[] }[]
): Promise<{ text: string; campaign?: Campaign, pricingTiers?: PricingTier[] }> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [...history, { role: "user", parts: [{ text: prompt }] }],
      config: {
        systemInstruction: systemInstruction,
        tools: [{ functionDeclarations: [createGoogleAdsCampaign, providePricingOptions] }],
      },
    });

    const text = response.text;
    let campaign: Campaign | undefined = undefined;
    let pricingTiers: PricingTier[] | undefined = undefined;

    if (response.functionCalls && response.functionCalls.length > 0) {
        for (const fc of response.functionCalls) {
            if (fc.name === 'createGoogleAdsCampaign') {
                campaign = fc.args as Campaign;
            }
            if (fc.name === 'providePricingOptions') {
                pricingTiers = (fc.args as { tiers: PricingTier[] }).tiers;
            }
        }
    }
    
    return { text, campaign, pricingTiers };
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return {
      text: "Sorry, I encountered an error while trying to generate advice. Please check the console for details and try again.",
      campaign: undefined,
      pricingTiers: undefined,
    };
  }
}